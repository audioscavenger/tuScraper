# -*- coding: utf-8 -*-
# python Scripts\pip.exe install pypiwin32 scrapy arrow
# pushd S:\wintools\PortableApps\Python27& scrapy shell https://mytumobile.towson.edu/app/catalog/classsection/TOWSN/1182/6764
# scrapy startproject tuScraper
# pushd S:\wintools\PortableApps\tuScraper& scrapy crawl tu1182v3 -o tu1182v3.json
# pushd %TEMP%\PortableApps\Python27\tuScraper
# scrapy crawl tu1182v3 -o tu1182v3.json
# https://doc.scrapy.org/en/latest/intro/tutorial.html#crawling
import scrapy, sqlite3, re, datetime, arrow
from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.linkextractors.sgml import SgmlLinkExtractor
numerics = ['ClassNumber', 'SeatsTaken', 'SeatsOpen', 'ClassCapacity', 'WaitListTotal', 'WaitListCapacity']
emptyPageList = ['Class Section', 'Course Catalog']
sqlClassCheck = "SELECT COUNT(1) FROM classes WHERE ClassNumber = (?)"

class Tu1182Spider(CrawlSpider):
  name = 'tu1182v3'
  baseUrl = 'https://mytumobile.towson.edu/app/catalog/classsection/TOWSN/1182/'
  start_urls = []
  nums = [6764,6765]
  for num in range(1000,9999): start_urls.append(baseUrl+str(num))
  # https://stackoverflow.com/questions/13952731/inserting-data-with-mysql-in-scrapy
  # db.close()

  def parse(self, response):
    if len(response.css('div.section-content div.pull-left div::text').extract()) == 0:
      db = sqlite3.connect('tuScraper/tuScraper.sqlite3')
      cursor = db.cursor()
      # page = response.url.split("/")[-1]
      # filename = 'tu-%s.html' % page
      # with open(filename, 'wb') as f: f.write(response.body)
      # self.log('Saved file %s' % filename)
      
      # classes={}
      keys=response.css('div.section-content div.pull-left div::text').extract()
      # Components is undefined in values, and Topic has a duplicate!
      keys.remove('Components')
      # cleanup keys by removing no alphanum characters:
      keys = [re.sub(r'\W+', '', i) for i in keys]
      
      values=response.css('div.section-content div.pull-right div::text').extract()
      
      classDict = dict(zip(keys,values))
      # create classDictValues with numeric values:
      classDictValues = { key: classDict[key] for key in numerics }
      
      # test for class in database here:
      cursor.execute(sqlClassCheck, (classDictValues['ClassNumber'],))
      if not cursor.fetchone()[0]:
        # remove numerics from classDict:
        for unwanted_key in numerics: del classDict[unwanted_key]
        
        # no need to reformat srt to int, sqlite will do it:
        # classes.update({int(classDict['Class Number']):classDict})
        
        # response.css('title::text').extract_first()
        # u'ITEC 470 - 101'
        
        # classDict.update({'title':response.css('title::text').extract_first()})
        # classes.update({int(classDict['Class Number']):classDict})
        # self.log('classDict %s' % classDict)
        
        #  cursor.execute("INSERT INTO classes(id, ) VALUES(?)", (num,))
        # cursor.execute("ALTER TABLE classes ADD "+re.sub(r'\W+', '', field)+" TEXT")
        
        # must use classDict because key order has certainly changed after zip:
        keys2insert = ','.join(classDict.keys())
        query_string = "INSERT INTO classes(ClassNumber,{}) VALUES ("+classDictValues['ClassNumber']+",%s)"
        query_string = query_string.format(keys2insert) % ','.join('?' * len(classDict.keys()))
        # 'INSERT INTO classes(Status,Meets,Dates,AddConsent,Description,Grading,ClassNumber,ClassCapacity,Instructors,WaitListCapacity,Topic,Career,Session,Location,Units,SeatsTaken,WaitListTotal,SeatsOpen,Campus,EnrollmentRequirements,Room) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        cursor.execute(query_string, classDict.values())
        db.commit()
      #
      keys2insert = ','.join(classDictValues.keys())
      query_string = "INSERT INTO history(timestamp,{}) VALUES ("+str(arrow.get(datetime.datetime.now()).timestamp)+",%s)"
      query_string = query_string.format(keys2insert) % ','.join('?' * len(classDictValues.keys()))
      cursor.execute(query_string, classDictValues.values())
      db.commit()
      
      yield classDict
