# -*- coding: utf-8 -*-
# pushd S:\wintools\PortableApps\Python27
# python Scripts\pip.exe install pypiwin32 scrapy arrow
# scrapy shell https://mytumobile.towson.edu/app/catalog/classsection/TOWSN/1182/6764
# scrapy startproject tuScraper
# pushd S:\wintools\PortableApps\tuScraper
# pushd %TEMP%\PortableApps\Python27\tuScraper

# scrapy crawl tu1182v5 -o tu1182v5.json
# python ..\Scripts\scrapy.exe crawl tu1182v5 -o tu1182v5.json

# https://doc.scrapy.org/en/latest/intro/tutorial.html#crawling
import scrapy, sqlite3, re, datetime, arrow, sys, logging
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors.sgml import SgmlLinkExtractor

version = 5.1
numerics = ['ClassNumber', 'SeatsTaken', 'SeatsOpen', 'ClassCapacity', 'WaitListTotal', 'WaitListCapacity']
keys2remove=['Components']
database='tuScraper.sqlite3'
sqlClassCheck = "SELECT COUNT(1) FROM classes WHERE ClassNumber = (?)"
sqlClassFetch = "SELECT ClassNumber FROM classes"
total=0
modulo=500

def dict_factory(cursor, row):
  d = {}
  for idx, col in enumerate(cursor.description):
      d[col[0]] = row[idx]
  return d


# https://stackoverflow.com/questions/10845839/writing-items-to-a-mysql-database-in-scrapy
class TuPipelineSpider(CrawlSpider):
  name = 'tu1182v5'
  baseUrl = 'https://mytumobile.towson.edu/app/catalog/classsection/TOWSN/1182/'
  start_urls = []
  # nums = [6764]
  # for num in nums: start_urls.append(baseUrl+str(num))
  # https://stackoverflow.com/questions/13952731/inserting-data-with-mysql-in-scrapy
  
  # for num in range(1000,7187): start_urls.append(baseUrl+str(num))
  
  db = sqlite3.connect(database)
  db.row_factory = dict_factory
  cursor = db.cursor()
  cursor.execute(sqlClassFetch)
  for row in cursor.execute(sqlClassFetch): start_urls.append(baseUrl+str(row["ClassNumber"]))
  
  def parse(self, response):
    keys=response.css('div.section-content div.pull-left div::text').extract()
    # if response.css('title::text').extract_first() not in ['Class Section', 'Course Catalog']:
    if len(keys) > 0:
      title = response.css('title::text').extract_first()
      # page = response.url.split("/")[-1]
      # filename = 'tu-%s.html' % page
      # with open(filename, 'wb') as f: f.write(response.body)
      # self.log('Saved file %s' % filename)
      
      # classes={}
      # cleanup keys by removing no alphanum characters:
      keys = [re.sub(r'\W+', '', i).encode("utf-8") for i in keys]
      
      # Components is undefined in values, Topic has a duplicate, and sometimes ClassCapacity=CombinedSectionCapacity
      # keys.remove('Components')
      # remove multiple items in the list:
      keys = [e for e in keys if e not in keys2remove]
      # translate CombinedSectionCapacity to ClassCapacity:
      keys=['ClassCapacity' if x=='CombinedSectionCapacity' else x for x in keys]
      
      values=response.css('div.section-content div.pull-right div::text').extract()
      ClassNumber=values[keys.index('ClassNumber')]
      if len(keys) > len(values):
        prevalues=response.css('div.section-content div.pull-right div').extract()
        # get indices of items containing "<div></div>":
        indices = [i for i, x in enumerate(prevalues) if x == "<div></div>"]
        # for each empty indice, add one in value:
        for i in indices: values.insert(i, "TBA")
      elif len(keys) < len(values):
        response = response.replace( body=re.sub(r"<br\s*[\/]?>", "\n", response.body) )
        values=response.css('div.section-content div.pull-right div::text').extract()
      if len(keys) < len(values):
        print 'ERROR for CLASS %s: len(keys)=%d len(values)=%d' % (ClassNumber, len(keys), len(values))
      
      self.logger.debug("ClassNumber %s: %d values + %d keys = %s" % (ClassNumber, len(keys), len(values), ','.join(keys)))
      classDict = dict(zip(keys,values))
      # create classDictValues with numeric values:
      # print classDict
      # print numerics
      classDictValues = { key: classDict[key] for key in numerics }
      
      # test for class in database here:
      db = sqlite3.connect(database)
      cursor = db.cursor()
      cursor.execute(sqlClassCheck, (ClassNumber,))
      if not cursor.fetchone()[0]:
        print 'INSERT CLASS: %s' % (ClassNumber)
        self.logger.info('INSERT CLASS: %s' % (ClassNumber))
        # remove numerics from classDict:
        for unwanted_key in numerics: del classDict[unwanted_key]
        # no need to reformat srt to int, sqlite will do it:
        # classes.update({int(classDict['Class Number']):classDict})
        
        # title = response.css('title::text').extract_first()
        # u'ITEC 470 - 101'
        
        # classDict.update({'title':response.css('title::text').extract_first()})
        # classes.update({int(classDict['Class Number']):classDict})
        # self.log('classDict %s' % classDict)
        
        #  cursor.execute("INSERT INTO classes(id, ) VALUES(?)", (num,))
        # cursor.execute("ALTER TABLE classes ADD "+re.sub(r'\W+', '', field)+" TEXT")
        
        # must use classDict because key order has certainly changed after zip:
        keys2insert = ','.join(classDict.keys())
        query_string = "INSERT INTO classes(ClassNumber,title,{}) VALUES ("+ClassNumber+","+title+",%s)"
        query_string = query_string.format(keys2insert) % ','.join('?' * len(classDict.keys()))
        # 'INSERT INTO classes(Status,Meets,Dates,AddConsent,Description,Grading,ClassNumber,ClassCapacity,Instructors,WaitListCapacity,Topic,Career,Session,Location,Units,SeatsTaken,WaitListTotal,SeatsOpen,Campus,EnrollmentRequirements,Room) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        # self.log('INSERT CLASS: %s - query_string=%s' % (ClassNumber,query_string))
        # print 'INSERT CLASS: %s - query_string=%s' % (ClassNumber,query_string)
        try:
          cursor.execute(query_string, classDict.values())
          db.commit()
        except sqlite3.Error, e:
          print "sqlite3.Error %s" % (e)
          self.logger.error("sqlite3.Error %s" % (e))
          # sqlite3.Error table classes has no column named Notes
          # sqlite3.Error table classes has no column named ClassAttributes
          # sqlite3.Error table classes has no column named InstructionMode
          # sqlite3.Error table classes has no column named DropConsent
      #
      # temporary correction, i forgot to insert class titles:
      # cursor = db.cursor()
      # query_string = "UPDATE classes SET title = ? WHERE ClassNumber = "+ClassNumber
      # cursor.execute(query_string, [title,])
      
      keys2insert = ','.join(classDictValues.keys())
      query_string = "INSERT INTO history(timestamp,{}) VALUES ("+str(arrow.get(datetime.datetime.now()).timestamp)+",%s)"
      query_string = query_string.format(keys2insert) % ','.join('?' * len(classDictValues.keys()))
      global total
      total+=1
      if (total>=modulo and total%modulo == 0):
        print 'UPDATED HISTO ROWS: %d - Current class: %s' % (total, ClassNumber)
      self.logger.info('UPDATE total HISTO: %d - Current class: %s' % (total, ClassNumber))
      # self.logger.info('UPDATE HISTO: %s' % (ClassNumber))
      cursor = db.cursor()
      # print 'UPDATE HISTO: %s' % (ClassNumber)
      try:
        cursor.execute(query_string, classDictValues.values())
        db.commit()
      except sqlite3.Error, e:
        print "sqlite3.Error %s" % (e)
        self.logger.error("sqlite3.Error %s" % (e))
      # yield classDict
