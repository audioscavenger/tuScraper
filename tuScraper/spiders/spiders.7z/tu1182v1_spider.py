# -*- coding: utf-8 -*-
# pushd S:\wintools\PortableApps\Python27
# scrapy startproject tuScraper
# cd tuScraper
# scrapy crawl tu1182v1
# https://doc.scrapy.org/en/latest/intro/tutorial.html#crawling
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

class Tu1182Spider(CrawlSpider):
  name = 'tu1182v1'
  
  def start_requests(self):
    baseUrl = 'https://mytumobile.towson.edu/app/catalog/classsection/TOWSN/1182/'
    nums = [6764,6765]
    for num in nums: yield scrapy.Request(url=baseUrl+str(num), callback=self.parse)
  
  def parse(self, response):
    page = response.url.split("/")[-1]
    filename = 'tu-%s.html' % page
    with open(filename, 'wb') as f: f.write(response.body)
    self.log('Saved file %s' % filename)
    
    classes={}
    key=response.css('div.section-content div.pull-left div::text').extract()
    value=response.css('div.section-content div.pull-right div::text').extract()
    
    # remove a particular element in a list:
    # key.remove('Components')
    
    classDict = dict(zip(key,value))
    # classes.update({int(classDict['Class Number']):classDict})
    
    # response.css('title::text').extract_first()
    # u'ITEC 470 - 101'
    
    # classDict.update({'title':response.css('title::text').extract_first()})
    # classes.update({int(classDict['Class Number']):classDict})
    self.log('classDict %s' % classDict)
